#!/usr/bin/env python
# coding: utf-8

# In[25]:


import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import LabelEncoder 
import seaborn as sns; sns.set()
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_log_error
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge, SGDRegressor, Lasso, ElasticNet
from sklearn.ensemble import RandomForestRegressor, AdaBoostRegressor, GradientBoostingRegressor, BaggingRegressor, ExtraTreesRegressor
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import cross_validate
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score


# In[26]:


#Reading the train data
df = pd.read_csv("train.csv")
y = df['SalePrice']


# In[27]:


#Removal of Outliers
removed = 0
thresh = 500000
for i in df.index:
    if y[i]>thresh:
        df = df.drop(i)
        removed+=1
print('Data points removed: '+str(removed))


# In[28]:


#Separating features and target variable
X = df.drop(['Id', 'SalePrice'], axis=1)
y = df['SalePrice']
df.shape


# In[29]:


#Separating numerical and categorical features
numeric_X = X[X.dtypes[X.dtypes != "object"].index]
categorical_X = X[X.dtypes[X.dtypes == "object"].index]
numeric_X.head()


# In[30]:


#Calculating the distribution of missing values for numerical features
parameter_na=[i for i in numeric_X.columns if numeric_X[i].isnull().sum()>1]

for i in parameter_na:
    print(i, np.round(numeric_X[i].isnull().mean(),2),' % missing values')


# In[31]:


#Calculating the distribution of misssing values for categorical features
#First removing features with "NA" as a parameter
categorical_X1 = categorical_X.drop(['Alley', 'BsmtQual', 'BsmtCond', 'BsmtExposure', 'BsmtFinType1', 'BsmtFinType2', 'FireplaceQu', 'GarageType', 'GarageFinish', 'GarageQual', 'GarageCond', 'PoolQC', 'Fence', 'MiscFeature'
], axis=1)

parameter_na=[i for i in categorical_X1.columns if categorical_X1[i].isnull().sum()>1]

for i in parameter_na:
    print(i, np.round(categorical_X1[i].isnull().mean(),2),' % missing values')


# In[32]:


#Removing the categorical feature with missing value
categorical_X = categorical_X.drop(['MasVnrType'], axis=1)


# In[33]:


#Imputing the missing values(Replacing NA with a suitable metric of the feature elements)
numeric_X = numeric_X.replace(np.nan,numeric_X['LotFrontage'].median())
numeric_X = numeric_X.replace(np.nan,numeric_X['MasVnrArea'].median())
numeric_X = numeric_X.replace(np.nan,numeric_X['GarageYrBlt'].mean())


# In[34]:


#Verifying that the missing values are replaced
k=0
for feat in numeric_X.columns:
    if(numeric_X[feat].isnull().sum()>1):
        k=k+1
if(k!=0):
    print("Missing values present")
else:
    print("No Missing Values")


# In[35]:


#Finding correlation between numerical features
corr = numeric_X.corr()

#Plotting the heat map
sns.heatmap(corr)
plt.show()

#Eliminating columns with high correlation (>0.8)
columns = np.full((corr.shape[0],), True, dtype=bool)
for i in range(corr.shape[0]):
    for j in range(i+1, corr.shape[0]):
        if corr.iloc[i,j] >= 0.8:
            if columns[j]:
                columns[j] = False
                print(columns[j])
                print(numeric_X.columns[j])
selected_columns = numeric_X.columns[columns]
new_features = numeric_X[selected_columns].values
print(new_features.shape)


# In[36]:


#Dropping the features having high correlation
numeric_X = numeric_X.drop(['1stFlrSF', 'TotRmsAbvGrd', 'GarageArea'], axis=1)


# In[37]:


#Replacing the "NA" value to a string to avoid any errors
for i in categorical_X:
    categorical_X = categorical_X.replace(np.nan,'NA')


# In[38]:


#Encoding categorical features
#First encoding unordered features using one-hot encoding
unordered = ['MSZoning','LotShape','LandContour', 'LotConfig',
                         'Neighborhood','Condition1', 'Condition2', 'BldgType',
                         'HouseStyle','RoofStyle','RoofMatl','Exterior1st','Exterior2nd',
                         'Foundation','Heating','GarageType','SaleType',
                         'SaleCondition','MiscFeature']
unordered = df[unordered]
unordered = pd.get_dummies(unordered)


# In[39]:


#Encoding ordered features using label encoding
ordered = ['Street','Alley','Utilities','LandSlope',
                      'ExterQual', 'ExterCond','BsmtQual','BsmtCond',
                       'BsmtExposure','BsmtFinType1','BsmtFinType2','HeatingQC',
                       'CentralAir','Electrical','KitchenQual','Functional',
                       'FireplaceQu','GarageFinish', 'GarageQual',
                       'GarageCond', 'PavedDrive','PoolQC','Fence']

# instantiate labelencoder object
le = LabelEncoder()
# apply le on categorical feature columns
for f in ordered:
    categorical_X[f] = le.fit_transform(categorical_X[f])
categorical_X.describe()


# In[40]:


#Combining the two types of categorical features
cat_X = pd.concat([categorical_X,unordered], axis=1)
cat_X.describe()


# In[41]:


#Making a Dataset
X_train = pd.concat([numeric_X, cat_X], axis=1)
X_train.describe()


# In[42]:


#Finding the correlation between target variable and features
temp_data = pd.concat([X_train,df['SalePrice']],axis=1)
corr = temp_data.corr()
useful_feat = []
for i in corr.columns:
    if (corr[i]['SalePrice'])>=.1 or (corr[i]['SalePrice'])<=-.1:
        useful_feat.append(i)
        
X_t = temp_data[useful_feat]
X_t = X_t.drop(['SalePrice'], axis=1)
X_t.describe()


# In[43]:


#Splitting into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X_t, y, test_size=0.15, random_state=42)


# In[ ]:


test_acc = []

for epoch in np.arange(1,101,1):
    print(epoch)
    X_train,X_test,Y_train,Y_test = train_test_split(X_t,y,test_size=0.15)
    model1 = ExtraTreesRegressor(bootstrap= True,
 max_depth= None,
 max_features= 'auto',
 min_samples_leaf= 1,
 min_samples_split= 2,
 n_estimators= 442)
    model2 = GradientBoostingRegressor(learning_rate= 0.05, n_estimators= 750,max_depth= 2,min_samples_leaf= 1, min_samples_split=2,
                              max_features='sqrt',subsample=0.85)
    model3 = RandomForestRegressor(bootstrap= False,
 max_depth= None,
 max_features= 'sqrt',
 min_samples_leaf= 1,
 min_samples_split= 2,
 n_estimators= 385)
    model1.fit(X_train,Y_train)
    model2.fit(X_train,Y_train)
    model3.fit(X_train,Y_train)
    y_pred = model1.predict(X_test)*0.15 + model2.predict(X_test)*0.7 + model3.predict(X_test)*0.15
    score_test = r2_score(Y_test,y_pred)
    test_acc.append(round(score_test,3))
    print(round(score_test,3))
test_acc = np.sort(test_acc)
fig, ax = plt.subplots(figsize=(6,4))
test = [t*100 for t in test_acc]
k = np.arange(1,101,1)
ax.plot(k,test,marker='o',color='r') 
ax.set_title('Accuracy')
ax.set_ylabel('Accuracy')
ax.set_xlabel('k')
plt.grid()
fig.tight_layout()
mean_test = round(np.mean(test),1)
std = round(np.std(test),1)
print("Test Accuracy: "+str(mean_test)+"+/-"+str(std))
print(test)
plt.show()


# In[44]:


#Reading the test file
df_test = pd.read_csv('test.csv')
df_test.shape


# In[45]:


test_X = df_test.drop(['Id'], axis=1)
test_X.shape


# In[46]:


numeric_X_test = test_X[test_X.dtypes[test_X.dtypes != "object"].index]
categorical_X_test = test_X[test_X.dtypes[test_X.dtypes == "object"].index]
numeric_X_test.shape


# In[47]:


parameter_na=[i for i in numeric_X_test.columns if numeric_X_test[i].isnull().sum()>1]

for i in parameter_na:
    print(i, np.round(numeric_X_test[i].isnull().mean(),2),' % missing values')


# In[48]:


#Imputing the missing values(Replacing NA with suitable metric of the feature elements)
numeric_X_test = numeric_X_test.replace(np.nan,numeric_X_test['LotFrontage'].median())
numeric_X_test = numeric_X_test.replace(np.nan,numeric_X_test['MasVnrArea'].median())
numeric_X_test = numeric_X_test.replace(np.nan,numeric_X_test['GarageYrBlt'].mean())
numeric_X_test = numeric_X_test.replace(np.nan,numeric_X_test['BsmtFullBath'].median())
numeric_X_test = numeric_X_test.replace(np.nan,numeric_X_test['BsmtHalfBath'].median())
numeric_X_test.shape


# In[49]:


numeric_X_test = numeric_X_test.drop(['1stFlrSF', 'TotRmsAbvGrd', 'GarageArea'], axis=1)


# In[50]:


#One hot encoding
unordered = ['MSZoning','LotShape','LandContour', 'LotConfig',
                         'Neighborhood','Condition1', 'Condition2', 'BldgType',
                         'HouseStyle','RoofStyle','RoofMatl','Exterior1st','Exterior2nd',
                         'Foundation','Heating','GarageType','SaleType',
                         'SaleCondition','MiscFeature']
unordered = df_test[unordered]
unordered = pd.get_dummies(unordered)


# In[51]:


cat_X_test = test_X[test_X.dtypes[test_X.dtypes == "object"].index]
cat_X_test = cat_X_test.drop(['MasVnrType'],axis=1)
for f in cat_X_test.columns:
    cat_X_test[f] = cat_X_test[f].replace(np.nan,"NA")

# apply le on categorical feature columns
for f in ordered:
    cat_X_test[f] = le.fit_transform(cat_X_test[f])
cat_X_test.describe()
cat_X_test.shape


# In[52]:


cat_X_test = pd.concat([cat_X_test, unordered], axis=1)


# In[53]:


X_test1 = pd.concat([numeric_X_test, cat_X_test], axis=1)
X_test1.shape


# In[55]:


useful_test = useful_feat
useful_test.pop(-1)


# In[56]:


X_test2 = X_test1[useful_test]
X_test2.describe()


# In[57]:


y_pred = model1.predict(X_test2)*0.15 + model2.predict(X_test2)*0.7 + model3.predict(X_test2)*0.15
df_test['SalePrice'] = y_pred


# In[40]:


df_val = pd.read_csv('sample_submission.csv')
y_pred.shape


# In[41]:


y_val = df_val['SalePrice']
y_val.shape


# In[42]:


print(mean_absolute_error(y_pred,y_val))  


# In[43]:


df_out = df_test['Id']
df_out.shape


# In[44]:


df_out = pd.concat([df_out, df_test['SalePrice']], axis=1)
df_out.shape


# In[45]:


df_out.to_csv('submission.csv')


# In[ ]:




