The packages used in this project are:
1. sklearn
2. matplotlib
3. numpy

The three csv files, train.csv, test.csv,sample_submission.csv, should be placed in the same folder as the code.

The notebook file .pynb and python file .py both are added to the folder. Any one could be run based on the convenience.
All the results will be shown automatically.

Thank you!